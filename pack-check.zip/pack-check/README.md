# jmthon userbot

## اهـلا بـك

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/JMTHON-AR/pack)

## شكـرا لكـم 


this userbot is import of catuserbot and translate to arabic

https://t.me/catuserbot_support
https://t.me/jmthon
